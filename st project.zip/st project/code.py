import mysql.connector
from datetime import date

con = mysql.connector.connect(
    host="localhost",
    user="root",
    password="Ap39cl7889",
    database="student_system"
)
cur = con.cursor()

def add_student():
    name = input("Enter name: ")
    age = int(input("Enter age: "))
    gender = input("Enter gender: ")
    cur.execute("INSERT INTO students (name, age, gender) VALUES (%s, %s, %s)", (name, age, gender))
    con.commit()
    print("Student added successfully!")

def view_students():
    cur.execute("SELECT * FROM students")
    rows = cur.fetchall()
    for row in rows:
        print(row)

def update_student():
    student_id = int(input("Enter student ID to update: "))
    name = input("Enter new name: ")
    age = int(input("Enter new age: "))
    gender = input("Enter new gender: ")
    cur.execute("UPDATE students SET name=%s, age=%s, gender=%s WHERE student_id=%s", (name, age, gender, student_id))
    con.commit()
    print("Student updated successfully!")

def delete_student():
    student_id = int(input("Enter student ID to delete: "))
    cur.execute("DELETE FROM students WHERE student_id = %s", (student_id,))
    con.commit()
    print("Student deleted successfully!")

def search_student():
    choice = input("Search by (1) ID or (2) Name? ")
    if choice == '1':
        student_id = int(input("Enter student ID: "))
        cur.execute("SELECT * FROM students WHERE student_id = %s", (student_id,))
    elif choice == '2':
        name = input("Enter student name: ")
        cur.execute("SELECT * FROM students WHERE name LIKE %s", (f"%{name}%",))
    else:
        print("Invalid choice.")
        return
    rows = cur.fetchall()
    for row in rows:
        print(row)

def add_marks():
    student_id = int(input("Enter student ID: "))
    subject = input("Enter subject: ")
    marks = int(input("Enter marks: "))
    cur.execute("INSERT INTO marks (student_id, subject, marks) VALUES (%s, %s, %s)", (student_id, subject, marks))
    con.commit()
    print("Marks added successfully!")
    
def view_marks():
    student_id = int(input("Enter student ID: "))
    cur.execute("SELECT subject, marks FROM marks WHERE student_id = %s", (student_id,))
    rows = cur.fetchall()
    for row in rows:
        print(row)

def mark_attendance():
    student_id = int(input("Enter student ID: "))
    status = input("Enter status (Present/Absent): ")
    today = date.today()
    cur.execute("INSERT INTO attendance (student_id, date, status) VALUES (%s, %s, %s)", (student_id, today, status))
    con.commit()
    print("Attendance marked!")

def view_attendance():
    student_id = int(input("Enter student ID: "))
    cur.execute("SELECT date, status FROM attendance WHERE student_id = %s", (student_id,))
    rows = cur.fetchall()
    for row in rows:
        print(row)

while True:
    print("\n--- Student Performance System ---")
    print("1. Add Student")
    print("2. View Students")
    print("3. Update Student")
    print("4. Delete Student")
    print("5. Add Marks")
    print("6. View Marks")
    print("7. Mark Attendance")
    print("8. View Attendance")
    print("9. Search Student by ID or Name")
    print("0. Exit")

    choice = input("Enter your choice: ")

    if choice == '1':
        add_student()
    elif choice == '2':
        view_students()
    elif choice == '3':
        update_student()
    elif choice == '4':
        delete_student()
    elif choice == '5':
        add_marks()
    elif choice == '6':
        view_marks()
    elif choice == '7':
        mark_attendance()
    elif choice == '8':
        view_attendance()
    elif choice == '9':
        search_student()
    elif choice == '0':
        print("Goodbye!")
        break
    else:
        print("Invalid choice. Try again.")
